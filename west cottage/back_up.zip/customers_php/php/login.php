<form id="alta-contacto" name="alta_frm" action="/loged_in.html" method="post" enctype="multipart/form-data">
	<fieldset>
		<div>
			<input type="submit" id="enviar-alta" class="cambio" name="enviar_btn" value="agregar" />
		</div>
		<?php include("php/mensajes.php"); ?>
	</fieldset>
</form>