<?php 
$consulta = "SELECT * FROM u148878710_contactos";
include("php/tabla-resultados.php");
?>