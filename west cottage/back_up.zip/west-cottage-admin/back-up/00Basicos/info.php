<?php
//esta funcion nos muestra la configuraci�n del servidor de aplicaciones
phpinfo();
?>